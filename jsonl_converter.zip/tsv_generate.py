#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pdb
import glob
import json
import numpy as np

# 'train', 'dev', 'test'
item = 'test'

if item == 'train':
    item_rev = 'training'
elif item == 'dev':
    item_rev = 'validation'
elif item == 'test':
    item_rev = 'test'


# In[2]:


lengths = []
def parseAce(annfn, entity_set, rel_set):
    entity_dir = {}
    rel_dir = {}
    for line in open(annfn):
        line = line.rstrip()
        
        if 'Arg1:' in line:
            print("yes")
            tokens = line.split('\t')
            key = tokens[0]
            rels = tokens[1].split()
            rel = rels[0]
            arg1 = rels[1].split(':')[-1]
            arg2 = rels[2].split(':')[-1]
            rel_dir[key] = {'relation':rel, 'arg1':arg1, 'arg2':arg2}
            rel_set.add(rel)
        else:
            tokens = line.split('\t')
            print("Tokens:", tokens)
            
            key = tokens[0]
            print("key:",key)
            
            print(tokens[1])
            offsets = tokens[1].split()[1:]
            offset0 = int(offsets[0])
            offset1 = int(offsets[1])
            ner = tokens[1].split()[0]
            keyphrase = tokens[2]
            global lengths
            lengths.append(len(keyphrase.split()))
            entity_dir[key] = {'ner':ner, 'offset': [offset0, offset1], 'keyphrase':keyphrase}
            entity_set.add(ner)

    return entity_dir, rel_dir


# In[3]:


#out_dir= r"C:\Users\av387942\Documents\Sabic-project\data\out_json"

docs = []
entity_set = set()
rel_set = set()
nercount = 0
relcount = 0
sentcount = 0

path = r'/Users/ryan/jsonl_converter/data/' + item + '_data'

for ann_fn in glob.glob(path+"/*.ann"):
    
    print(ann_fn)
    
    entity_dir, relation_dir = parseAce(ann_fn, entity_set, rel_set)
    #parses, token_dict_offset1, token_dict_offset2 = parseStanford(ann_fn)
    
    print("Entities Dir:", entity_dir)
    print("Relations Dir:", relation_dir)
    


# In[4]:


### Entity LISTS

docs = []
entity_set = set()
rel_set = set()
nercount = 0
relcount = 0
sentcount = 0

fn_list=[]
label_list = []
char_start_list = []
char_end_list = []
text_list = []
entity_list=[]
col = []

path = r'/Users/ryan/jsonl_converter/data/' + item + '_data'

for ann_fn in glob.glob(path+"/*.ann"):
    print(ann_fn)
    
    entity_dir, relation_dir = parseAce(ann_fn, entity_set, rel_set)
    
    fn = ann_fn.split('/')[-1].replace('.ann','')
    fn = fn.replace('/Users/ryan/jsonl_converter/data/' + item + 'train_data', '')
    
    entity_id = entity_dir.keys()

    for entity in entity_id:
        label = entity_dir[entity]['ner']
        char_start = entity_dir[entity]['offset'][0]
        char_end = entity_dir[entity]['offset'][1]
        text = entity_dir[entity]['keyphrase']
       
        fn_list.append(fn)
        entity_list.append(entity)
        label_list.append(label)
        char_start_list.append(char_start)
        char_end_list.append(char_end)
        text_list.append(text)
    

print(len(fn_list),len(entity_list),len(label_list),len(char_start_list),len(char_end_list),len(text_list))


# In[5]:


### Entity TSV
import pandas as pd
 
df_entity = pd.DataFrame({"doc_key":fn_list,"entity_id":entity_list,"label":label_list,"char_start":char_start_list,"char_end":char_end_list,"text":text_list})

print(df_entity.head())

df_entity["doc_key"].unique()

df_entity.to_csv(item_rev + '_entities.tsv', sep = '\t')


# In[6]:


docs = []
entity_set = set()
rel_set = set()
nercount = 0
relcount = 0
sentcount = 0


ann_fn = r'/Users/ryan/jsonl_converter/data/test_data/100005.ann'
fn = ann_fn.split('/')[-1].replace('.ann','')
entity_dir, relation_dir = parseAce(ann_fn, entity_set, rel_set)
print(relation_dir)
fn = ann_fn.split('/')[-1].replace('.ann','')
cpr_groups = relation_dir.keys()
print(cpr_groups)
eval_type="N"
# label= relation_dir["R1"]["relation"]
# print(label)
# arg1 = relation_dir["R1"]['arg1']
# arg2 = relation_dir["R1"]['arg2']

# print(arg1,arg2)


# In[7]:


### Relation LISTS

docs = []
entity_set = set()
rel_set = set()
nercount = 0
relcount = 0
sentcount = 0

fn_list=[]
cpr_grp_list = []
eval_type_list = []
label_list = []
arg1_list = []
arg2_list = []
entity_list=[]
col = []

path = r'/Users/ryan/jsonl_converter/data/' + item + '_data'
for ann_fn in glob.glob(path+"/*.ann"):
    
    print(ann_fn)
    
    entity_dir, relation_dir = parseAce(ann_fn, entity_set, rel_set)


    fn = ann_fn.split('/')[-1].replace('.ann','')
    fn = fn.replace("/Users/ryan/jsonl_converter/data/" + item + "_data",'')
    
    eval_type="N"
    
    relation_id = relation_dir.keys()

    for relation in relation_id:
          
        arg1 = relation_dir[relation]['arg1']
        arg2 = relation_dir[relation]['arg2']
        label= relation_dir[relation]["relation"]
       
        fn_list.append(fn)
        cpr_grp_list.append(relation)
        eval_type_list.append(eval_type)
        label_list.append(label)
        arg1_list.append(arg1)
        arg2_list.append(arg2)
    

print(len(fn_list),len(cpr_grp_list),len(label_list),len(eval_type_list),len(arg1_list),len(arg2_list))


# In[8]:


### Relation TSV
import pandas as pd
 
df_relation = pd.DataFrame({"doc_key":fn_list,"cpr_group":cpr_grp_list,"eval_type":eval_type_list,"label":label_list,"arg1":arg1_list,"arg2":arg2_list})

print(df_relation.head())

df_relation.to_csv(item_rev + "_relations.tsv", sep = '\t')


# In[9]:


#Abstracts TSV
path = r'/Users/ryan/jsonl_converter/data/' + item + '_data'

fn_list=[]
title_list=[]
abstract_list=[]

for txt_fn in glob.glob(path+"/*.txt"):
    
    fn = txt_fn.split('/')[-1].replace('.txt','')
    fn = fn.replace("/Users/ryan/jsonl_converter/data/" + item + "_data",'')
    
    txtfile = open(txt_fn, "rt")
    title = txtfile.readline()  
    abstract = txtfile.read()
    
    title = title.replace('\n','')
    fn_list.append(fn)
    title_list.append(title)
    abstract_list.append(abstract)
    
    
txtfile.close()

print(fn_list)
print(title_list)
    
    


# In[10]:


import pandas as pd
 
df_abstract = pd.DataFrame({"doc_key":fn_list,"title":title_list,"abstract":abstract_list})

print(df_abstract.head())
df_abstract.to_csv(item_rev + "_abstracts.tsv", sep = '\t')


# In[ ]:





# In[ ]:




