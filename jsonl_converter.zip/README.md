1. Run the generate_tsv.ipynb after specifying the paths to train, validation and test data containing the .ann and .txt files to generate the TSVs. Make sure that thereare no empty lines at the end in .ann files. 

2. Run the chem_input.py to obtain the training, validation and test jsonl required for training DYGIE++ after specifying the appropriate data paths.
